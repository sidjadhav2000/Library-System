from flask import Flask, request, jsonify
import sqlite3
import os

app = Flask(__name__)

# Database connection 
def connect_db():
    db_path = r'C:\All learnings\Assess\lib_system\library.db'
    if not os.path.exists(db_path):
        raise FileNotFoundError(f"Database file not found at {db_path}")
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row  # Enables dictionary-like access
    return conn


@app.route('/check-db-connection', methods=['GET'])
def check_db_connection():
    try:
        conn = connect_db()
        conn.execute("SELECT 1")  # A simple query to ensure the connection works
        conn.close()
        return jsonify({"message": "Database connection successful"}), 200
    except sqlite3.Error as e:
        return jsonify({"error": "Failed to connect to the database", "details": str(e)}), 500


@app.route('/')
def home():
    return "Library Management System API"


# Create a book
@app.route('/books', methods=['POST'])
def create_book():
    data = request.get_json()
    title = data.get('title')
    author = data.get('author')
    available_copies = data.get('available_copies', 0)

    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute(
        "INSERT INTO books (title, author, available_copies) VALUES (?, ?, ?)",
        (title, author, available_copies),
    )
    conn.commit()
    conn.close()

    return jsonify({"message": "Book added successfully"}), 201

@app.route('/books', methods=['GET'])
def get_books():
    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM books")
    books = [dict(row) for row in cursor.fetchall()]
    conn.close()

    return jsonify(books), 200


@app.route('/books/<int:book_id>', methods=['PUT'])
def update_book(book_id):
    data = request.get_json()
    title = data.get('title')
    author = data.get('author')
    available_copies = data.get('available_copies')

    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute(
        "UPDATE books SET title = ?, author = ?, available_copies = ? WHERE id = ?",
        (title, author, available_copies, book_id),
    )
    conn.commit()
    conn.close()

    return jsonify({"message": "Book updated successfully"}), 200


@app.route('/books/<int:book_id>', methods=['DELETE'])
def delete_book(book_id):
    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM books WHERE id = ?", (book_id,))
    conn.commit()
    conn.close()

    return jsonify({"message": "Book deleted successfully"}), 200

@app.route('/books/search', methods=['GET'])
def search_books():
    query = request.args.get('query', '')

    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute(
        "SELECT * FROM books WHERE title LIKE ? OR author LIKE ?",
        (f"%{query}%", f"%{query}%"),
    )
    books = [dict(row) for row in cursor.fetchall()]
    conn.close()

    return jsonify(books), 200

# Pagination for books
@app.route('/books/paginate', methods=['GET'])
def paginate_books():
    page = int(request.args.get('page', 1))
    per_page = int(request.args.get('per_page', 5))
    offset = (page - 1) * per_page

    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute(
        "SELECT * FROM books LIMIT ? OFFSET ?", (per_page, offset)
    )
    books = [dict(row) for row in cursor.fetchall()]
    conn.close()

    return jsonify(books), 200



# Create a member
@app.route('/members', methods=['POST'])
def create_member():
    data = request.get_json()
    name = data.get('name')
    email = data.get('email')

    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute(
        "INSERT INTO members (name, email) VALUES (?, ?)", (name, email)
    )
    conn.commit()
    conn.close()

    return jsonify({"message": "Member added successfully"}), 201


@app.route('/members', methods=['GET'])
def get_members():
    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM members")
    members = [dict(row) for row in cursor.fetchall()]
    conn.close()

    return jsonify(members), 200


@app.route('/members/<int:member_id>', methods=['PUT'])
def update_member(member_id):
    data = request.get_json()
    name = data.get('name')
    email = data.get('email')

    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute(
        "UPDATE members SET name = ?, email = ? WHERE id = ?",
        (name, email, member_id),
    )
    conn.commit()
    conn.close()

    return jsonify({"message": "Member updated successfully"}), 200

@app.route('/members/<int:member_id>', methods=['DELETE'])
def delete_member(member_id):
    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM members WHERE id = ?", (member_id,))
    conn.commit()
    conn.close()

    return jsonify({"message": "Member deleted successfully"}), 200

if __name__ == '__main__':
    app.run(debug=True)
